import { useModels } from "@/hooks/use-models";
import { ModelCard } from "@/components/ModelCard";
import { Layout } from "@/components/Layout";
import { Loader2, Cuboid, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { data: models, isLoading, isError } = useModels();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="mb-20 text-center sm:text-left relative">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-primary/10 blur-[100px] rounded-full pointer-events-none" />
        
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-primary mb-6 animate-fade-in">
          <Sparkles className="w-3.5 h-3.5" />
          Premium 3D Assets
        </div>
        
        <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-[1.1] animate-fade-in" style={{ animationDelay: '100ms' }}>
          Elevate your <br className="hidden sm:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/50">digital experiences.</span>
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl sm:mx-0 mx-auto animate-fade-in" style={{ animationDelay: '200ms' }}>
          Explore our curated collection of high-end 3D models. Ready to integrate into your next web, AR, or VR masterpiece.
        </p>
      </section>

      {/* Grid Section */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 animate-pulse">
          <Loader2 className="w-10 h-10 animate-spin text-primary/50 mb-4" />
          <p className="text-muted-foreground font-medium tracking-wide">INITIALIZING ASSETS</p>
        </div>
      ) : isError ? (
        <div className="glass-panel rounded-2xl p-10 text-center max-w-lg mx-auto">
          <Cuboid className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">Connection Interrupted</h3>
          <p className="text-muted-foreground">Failed to load the model repository. Please try again later.</p>
        </div>
      ) : !models || models.length === 0 ? (
        <div className="glass-panel rounded-2xl p-16 text-center max-w-2xl mx-auto border-dashed border-white/20 animate-fade-in">
          <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
            <Cuboid className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-2xl font-display font-bold mb-3">No Models Yet</h3>
          <p className="text-muted-foreground mb-8">The gallery is currently empty. Be the first to add a stunning 3D model to the collection.</p>
          <Link 
            href="/admin" 
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:scale-105 active:scale-95 transition-all shadow-[0_0_20px_rgba(255,255,255,0.3)]"
          >
            Upload Asset
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {models.map((model, idx) => (
            <ModelCard key={model.id} {...model} index={idx} />
          ))}
        </div>
      )}
    </Layout>
  );
}
