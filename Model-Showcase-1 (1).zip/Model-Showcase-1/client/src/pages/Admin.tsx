import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertModelSchema } from "@shared/schema";
import { z } from "zod";
import { useCreateModel } from "@/hooks/use-models";
import { Layout } from "@/components/Layout";
import { Loader2, UploadCloud, Link as LinkIcon, FileText, Type } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

type FormValues = z.infer<typeof insertModelSchema>;

export default function Admin() {
  const { mutate: createModel, isPending } = useCreateModel();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const form = useForm<FormValues>({
    resolver: zodResolver(insertModelSchema),
    defaultValues: {
      name: "",
      description: "",
      fileUrl: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    createModel(data, {
      onSuccess: () => {
        toast({
          title: "Asset Published",
          description: "Your 3D model has been successfully added to the gallery.",
          className: "glass-panel border-green-500/20",
        });
        setLocation("/");
      },
      onError: (error) => {
        toast({
          title: "Upload Failed",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto animate-fade-in">
        <div className="mb-10 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-transparent rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-primary/5 border border-primary/10">
            <UploadCloud className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-display text-4xl font-bold mb-4">Publish Asset</h1>
          <p className="text-muted-foreground">Add a new 3D model to the public gallery by providing a valid .glb or .gltf file URL.</p>
        </div>

        <div className="glass-panel rounded-3xl p-8 sm:p-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 blur-[80px] rounded-full pointer-events-none" />
          
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 relative z-10">
            
            {/* Name Input */}
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Type className="w-4 h-4 text-muted-foreground" /> Model Name
              </label>
              <input
                id="name"
                {...form.register("name")}
                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-foreground placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all"
                placeholder="e.g. Cyberpunk Hovercar"
              />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive mt-1">{form.formState.errors.name.message}</p>
              )}
            </div>

            {/* URL Input */}
            <div className="space-y-2">
              <label htmlFor="fileUrl" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-muted-foreground" /> .GLB File URL
              </label>
              <input
                id="fileUrl"
                {...form.register("fileUrl")}
                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-foreground placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all font-mono text-sm"
                placeholder="https://example.com/models/car.glb"
              />
              {form.formState.errors.fileUrl && (
                <p className="text-sm text-destructive mt-1">{form.formState.errors.fileUrl.message}</p>
              )}
            </div>

            {/* Description Input */}
            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <FileText className="w-4 h-4 text-muted-foreground" /> Description
              </label>
              <textarea
                id="description"
                {...form.register("description")}
                rows={4}
                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-foreground placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all resize-none"
                placeholder="Detailed description of the 3D asset..."
              />
              {form.formState.errors.description && (
                <p className="text-sm text-destructive mt-1">{form.formState.errors.description.message}</p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isPending}
              className="w-full mt-4 flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-primary text-primary-foreground font-bold text-lg hover:bg-primary/90 hover:shadow-[0_0_30px_rgba(255,255,255,0.2)] active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none transition-all duration-300"
            >
              {isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Publishing Asset...
                </>
              ) : (
                <>
                  Publish Asset <UploadCloud className="w-5 h-5 ml-1" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </Layout>
  );
}
