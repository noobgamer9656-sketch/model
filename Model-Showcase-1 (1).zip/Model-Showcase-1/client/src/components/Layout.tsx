import { Link, useLocation } from "wouter";
import { Hexagon, Heart, PlusCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { toast } = useToast();

  const handleDonate = () => {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
      window.location.href = "upi://pay?pa=YOUR_ID@upi&pn=YOUR_NAME&cu=INR";
    } else {
      toast({
        title: "Mobile Device Required",
        description: "UPI payments are only supported on mobile devices. Please visit this site on your phone to donate.",
        variant: "default",
        className: "glass-panel border-primary/20",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Premium Header */}
      <header className="sticky top-0 z-50 w-full border-b border-white/[0.05] bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300 group-hover:scale-105">
              <Hexagon className="w-5 h-5 text-primary-foreground fill-current" />
            </div>
            <div>
              <span className="font-display font-bold text-xl tracking-tight block leading-tight text-foreground">AURA</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground block leading-none">Studios</span>
            </div>
          </Link>

          <nav className="flex items-center gap-4 sm:gap-6">
            <Link 
              href="/admin" 
              className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-2 ${location === '/admin' ? 'text-primary' : 'text-muted-foreground'}`}
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Add Model</span>
            </Link>
            
            <button
              onClick={handleDonate}
              className="group relative flex items-center gap-2 px-5 py-2.5 rounded-full overflow-hidden transition-transform hover:scale-105 active:scale-95"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-rose-500/20 to-orange-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute inset-0 border border-white/10 rounded-full group-hover:border-rose-500/50 transition-colors duration-300" />
              <Heart className="w-4 h-4 text-rose-400 group-hover:fill-rose-400 transition-all duration-300" />
              <span className="text-sm font-semibold text-white/90">Donate</span>
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {children}
      </main>

      <footer className="border-t border-white/[0.05] py-8 text-center">
        <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
          Crafted with <Heart className="w-3 h-3 text-rose-500/70" /> for creators
        </p>
      </footer>
    </div>
  );
}
