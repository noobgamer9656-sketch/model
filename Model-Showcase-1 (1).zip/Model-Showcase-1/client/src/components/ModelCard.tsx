import { Download, Box, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import '@google/model-viewer';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        src?: string;
        'auto-rotate'?: boolean;
        'camera-controls'?: boolean;
        alt?: string;
        exposure?: string;
        'shadow-intensity'?: string;
        loading?: 'auto' | 'lazy' | 'eager';
        [key: string]: any;
      };
    }
  }
}

interface ModelCardProps {
  id: number;
  name: string;
  description: string;
  fileUrl: string;
  index: number;
}

export function ModelCard({ name, description, fileUrl, index }: ModelCardProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Add a slight delay just to show the beautiful loading state briefly on slow connections
    const timer = setTimeout(() => setIsLoaded(true), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div 
      className="group relative flex flex-col rounded-2xl glass-panel overflow-hidden transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_20px_40px_rgba(0,0,0,0.6)] animate-fade-in"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      {/* 3D Viewer Container */}
      <div className="relative h-64 w-full bg-black/40 overflow-hidden">
        {/* Abstract background gradient for the viewer */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/[0.03] to-transparent pointer-events-none" />
        
        {!isLoaded && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground z-10">
            <Loader2 className="w-8 h-8 animate-spin mb-2 text-primary/40" />
            <span className="text-xs uppercase tracking-widest font-medium">Loading Asset</span>
          </div>
        )}

        <model-viewer
          src={fileUrl}
          alt={`3D model of ${name}`}
          auto-rotate
          camera-controls
          exposure="1"
          shadow-intensity="1"
          class={`w-full h-full transition-opacity duration-700 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        />
        
        {/* Floating badge */}
        <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-xs font-medium">
          <Box className="w-3.5 h-3.5 text-primary" />
          3D Model
        </div>
      </div>

      {/* Content */}
      <div className="p-6 flex flex-col flex-1">
        <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">{name}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-6 flex-1">
          {description}
        </p>
        
        <div className="pt-4 border-t border-white/[0.05] mt-auto">
          <a 
            href={fileUrl} 
            download
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center w-full gap-2 px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-sm font-semibold transition-all duration-300 group/btn"
          >
            <Download className="w-4 h-4 group-hover/btn:-translate-y-0.5 transition-transform" />
            Download .glb
          </a>
        </div>
      </div>
    </div>
  );
}
