import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type ModelInput, type ModelResponse, type ModelsListResponse } from "@shared/routes";

export function useModels() {
  return useQuery<ModelsListResponse>({
    queryKey: [api.models.list.path],
    queryFn: async () => {
      const res = await fetch(api.models.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch models");
      return api.models.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateModel() {
  const queryClient = useQueryClient();
  
  return useMutation<ModelResponse, Error, ModelInput>({
    mutationFn: async (data: ModelInput) => {
      const validated = api.models.create.input.parse(data);
      const res = await fetch(api.models.create.path, {
        method: api.models.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const errorData = await res.json();
          throw new Error(errorData.message || "Validation failed");
        }
        throw new Error("Failed to create model");
      }
      return api.models.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.models.list.path] });
    },
  });
}
