## Packages
@google/model-viewer | Web component required to render 3D models in the browser

## Notes
- The app enforces a dark mode, modern aesthetic natively.
- Using regex on `navigator.userAgent` to detect mobile devices for the UPI donate button.
- `@google/model-viewer` relies on WebGL and requires a valid `.glb` or `.gltf` file URL. Ensure CORS is enabled on the server hosting the model files if they are external.
