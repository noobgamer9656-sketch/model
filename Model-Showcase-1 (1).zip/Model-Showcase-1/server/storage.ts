import { db } from "./db";
import {
  models,
  type CreateModelRequest,
  type ModelResponse
} from "@shared/schema";

export interface IStorage {
  getModels(): Promise<ModelResponse[]>;
  getModel(id: number): Promise<ModelResponse | undefined>;
  createModel(model: CreateModelRequest): Promise<ModelResponse>;
}

export class DatabaseStorage implements IStorage {
  async getModels(): Promise<ModelResponse[]> {
    return await db.select().from(models);
  }

  async getModel(id: number): Promise<ModelResponse | undefined> {
    const results = await db.select().from(models).where((models) => models.id === id);
    return results[0];
  }

  async createModel(model: CreateModelRequest): Promise<ModelResponse> {
    const [created] = await db.insert(models).values(model).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
